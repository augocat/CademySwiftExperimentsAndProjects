import Foundation
//
print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("||||||||||||||||||||||======1000. Structs======||||||||||||||||||||")
print("|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||")
print("===============================================================")
print("================1.Exercise: Creating a Structure==============")
print("===============================================================")
//1.  Create a structure named BookA without any properties.
//2.  Inside of BookA, add the properties:
//•  title with type String.
//•  pages with type Int.

// Write your code below: 📚

print("===============================================================")
print("================2.Exercise: Default Property Values==============")
print("===============================================================")
//•  In the provided BookB struct, give the following default values for:
//•  title to be "".
//•  pages to be 0.

struct BookB {
// Add your code below 📚
  

}
print("===============================================================")
print("================3.Exercise: Creating an Instance==============")
print("===============================================================")
//1.  Given the BookC structure, create an instance of BookC and save it to a variable called myFavBookC.

struct BookC {
  var pages = 0
  var title = ""
}
// Write your code below: 📚

print("===============================================================")
print("================4.Exercise: Accessing and Editing Properties==============")
print("===============================================================")
//1.  Print out the value of myFavBookD‘s .pages property.
//2.  It turns out that myFavBookD actually has 640 pages! Change the value of .pages to 640.
//Then, print out the value of myFavBookD‘s .pages property.
//3.  While we’re at it, let’s also give myFavBookD an actual title.
//Assign myFavBookD.title a String value that contains the title of your favorite book.
//Afterward, print out the value of myFavBookD.title.
struct BookD {
  var pages = 0
  var title = ""
}

var myFavBookD = BookD()
// Write your code below: 📚

print("===============================================================")
print("================5.Exercise: The Init() Method==============")
print("===============================================================")
//1.  In the BookE struct, create an init() method that has two parameters:
//•  title that is type String.
//•  pages that is type Int.
//2.  Create an instance of a BookE named theHobbit with the values title: "The Hobbit" and pages: 300.
struct BookE {
  var title: String
  var pages: Int
// Add your init() below
  
  
}
// Add your instance below 📚

print("===============================================================")
print("================6.Exercise: Memberwise Initialization==============")
print("===============================================================")
//1.  Create a struct called BandA that has three properties:
//•  genre of type String.
//•  members of type Int.
//•  isActive of type Bool.
//2.  Under the struct definition, create an instance of BandA called maroon5 that takes the arguments:
//•  genre with a value of "pop".
//•  members with a value of 5.
//•  isActive with a value of true.

// Add your code below 🎹 🎸 🥁

print("===============================================================")
print("================7.Exercise: Structure Methods==============")
print("===============================================================")
//1.  Create an instance method inside BandB called pumpUpCrowd:
//•  The pumpUpCrowd() method should not have any parameters and returns a String.
//•  Inside the pumpUpCrowd() method, return an empty string ("") for now.
//2.  Inside the body of the method:
//•  Check if self.isActive is true.
//•  If it evaluates to true, return "Are you ready to ROCK?".
//•  Otherwise, return "...".
//3.  Create an instance of Band called fooFighters that takes the arguments:
//•  genre: "rock".
//•  members: 6.
//•  isActive: true.
//4.  Print out the returned value of calling the .pumpUpCrowd() on fooFighters.
//What do you think will print?
struct BandB {
  var genre: String
  var members: Int
  var isActive: Bool

  init(genre: String, members: Int, isActive: Bool) {
    self.genre = genre
    self.members = members
    self.isActive = isActive
  }
// Add your method below 🤘
  
}
// Create your instance below 🎸 🥁

print("===============================================================")
print("================8.Exercise: Mutating Methods==============")
print("===============================================================")
//1.  In the BandC structure, let’s create the basis of our mutating method:
//•  the mutating method should be called changeGenre() and it has a single parameter newGenre: String and returns a String.
//•  Inside the method body, return an empty string "".
//2.  Now to fill in the body of the method. Inside the body of changeGenre():
//•  Assign self.genre as newGenre.
//•  Return self.genre instead of "".
//3.  Under the declaration of journey, create a variable named bandsNewGenre call .changeGenre() on journey with the argument newGenre: "rock".
//Then print out bandsNewGenre to see the changed value.
struct BandC {
  var genre: String
  var members: Int
  var isActive: Bool

  init(genre: String, members: Int, isActive: Bool) {
    self.genre = genre
    self.members = members
    self.isActive = isActive
  }

  func pumpUpCrowd() -> String {
    if self.isActive {
      "Are you ready to ROCK?"
    } else {
      "..."
    }
  }
// Add your mutating method below 🔧
  
}

var journey = BandC(genre: "jazz", members: 5, isActive: true)
// Change the genre below 🎸 🔨

print("===============================================================")
print("================9.Exercise: New Type==============")
print("===============================================================")
//1.  Let’s see type() in use in our own code.
//Use a print() statement to print out the value of type(of: journey).
//2.  Underneath th BandD struct create a Recorder struct with properties:
// name of type String.
// yearsOfExperience of type Int.
// create an init() method also.
//3. Create a third ConcertD struct with the two different Types of structs above for paramaters:
//• bands should be an array of Strings
//• recorders should be an array of Strings
//4.  Outside and after the ConcertD struct create a concert instance:
//First band
//•  name: "bts"
//•  genre: "kpop"
//•  members: 7
//•  isActive: true
//Second band
//•  name: "journey"
//•  genre: "rock"
//•  members: 5
//•  isActive: true
//Third band
//•  name: "fooFighters"
//•  genre: "rock"
//•  members: 6
//•  isActive: true
//First recorder
//•  name: "jimmy",
//•  yearsOfExperience: 10),
//Second recorder
//•  name: "james",
//•  yearsOfExperience: 15)
//Third recorder
//•  name: "jason",
//•  yearsOfExperience: 20)
//5. Assign to variables bandNames and recorderNames, using forEach loops to extract each one
//6. Print out each variable.
//
struct BandD {
  var name: String
  var genre: String
  var members: Int
  var isActive: Bool

  init(name: String, genre: String, members: Int, isActive: Bool) {
    self.name = name
    self.genre = genre
    self.members = members
    self.isActive = isActive
  }
  func pumpUpCrowd() -> String {
    if self.isActive {
      "Are you ready to ROCK?"
    } else {
      "..."
    }
  }
  mutating func changeGenre(newGenre: String) -> String {
    self.genre = newGenre
    return self.genre
  }
}
// Add your code below 📻

print("===============================================================")
print("================10.Exercise: Structures are Value Types==============")
print("===============================================================")
//1.  In Darwin.swift, under the created groundFinch, create another variable called cactusFinch that has the value of groundFinch.
//2.  Assign the cactusFinch.nestLocation to "Cactus".
//3.  Time to check the values and confirm that only cactusFinch‘s .nestLocation changed.
//Add a print() statement and print out cactusFinch.nestLocation.
//In a separate print(), output the value of groundFinch.nestLocation.
struct Finch {
  var lengthInCm: Double
  var nestLocation: String

  init(lengthInCm: Double, nestLocation: String) {
    self.lengthInCm = lengthInCm
    self.nestLocation = nestLocation
  }
}

var groundFinch = Finch(lengthInCm: 15.0, nestLocation: "Bush")
// Add your code below 🐦
